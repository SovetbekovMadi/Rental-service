//
//  ViewController.swift
//  Rental Service
//
//  Created by Amir Shokubassov on 3/9/20.
//  Copyright © 2020 Amir Shokubassov. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

